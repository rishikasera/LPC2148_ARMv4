#include <LPC214x.H>                       /* LPC21xx definitions */
#include "ext_int.h"

int main (void) 
{
  init_ext_interrupt();   // initialize the external interrup

  while (1)  
  {
  }
}
